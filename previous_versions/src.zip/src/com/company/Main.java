package com.company;

public class Main {
    public static void main(String[] args) {
	    System.out.println("Hello world");

	    Scene scene = new Scene();
	    GameObject go = new GameObject(scene);
	    go.addComponent(new SpriteRenderer());
	    System.out.println(go.getComponent(SpriteRenderer.class));
    }
}
