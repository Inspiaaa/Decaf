package com.company;

public class Transform extends Component {
    public Vector2 position;
    public float rotation;
}
