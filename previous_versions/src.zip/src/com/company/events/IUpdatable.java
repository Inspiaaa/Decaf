package com.company.events;

public interface IUpdatable {
    public void onUpdate();
}
