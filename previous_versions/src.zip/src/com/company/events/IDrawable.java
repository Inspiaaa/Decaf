package com.company.events;

public interface IDrawable {
    public void onDraw();
}
