package com.company;

public class Time {
    public static float deltaTime;
    public static float time;

    public static void update() {

    }
}
