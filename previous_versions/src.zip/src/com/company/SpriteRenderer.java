package com.company;

import com.company.events.IDrawable;
import com.company.events.IUpdatable;

public class SpriteRenderer extends Component implements IUpdatable, IDrawable {
    public void onStart() {

    }

    public void onUpdate() {

    }

    public void onDraw() {

    }
}
